# Radar Local

Painel local em português. Pesquisa estabelecimentos em Portugal ou nos Estados Unidos e exibe os que aparecem sem site cadastrado no Google Maps. O campo vazio indica ausência de site no cadastro, portanto confirme o caso individualmente.

## Abrir

1. Instale o Node.js 24 ou superior e extraia o ZIP.
2. Abra o PowerShell na pasta extraída e execute `node --env-file-if-exists=.env server.mjs`.
3. Aceda a [http://localhost:8765](http://localhost:8765). A interface e o editor funcionam sem credenciais. A busca e o envio requerem a configuração abaixo.

## Ligar Google Maps e Gmail

1. No [Google Cloud Console](https://console.cloud.google.com/), crie ou selecione um projeto e ative a **Places API (New)** e a **Gmail API**. Configure o faturamento para a Places API e restrinja a chave à Places API (New). O campo de site pode acionar uma tarifa Enterprise do Text Search. Confira os [preços](https://developers.google.com/maps/billing-and-pricing/pricing) e quotas.
2. Em **Google Auth Platform**, configure a aplicação. Se estiver em teste externo, inclua o seu endereço Gmail como utilizador de teste. Crie um cliente OAuth do tipo **Aplicação Web** e registe `http://localhost:8765/oauth/callback` como URI de redirecionamento autorizado. Se alterar PORT, registe a porta correspondente.
3. Copie `.env.example` para `.env`, preencha a chave da Places API e o ID e segredo do cliente OAuth. Guarde o ficheiro localmente. Reinicie o servidor e clique **Ligar Gmail**. A aplicação pede apenas a permissão de envio, e a autorização na sessão expira. Pode remover o acesso nas [ligações da sua conta Google](https://myaccount.google.com/connections).

## Usar

- Pesquise por cidade e segmento. Lisboa e Miami são os pontos de partida. Em cidades americanas, indique também a sigla do estado para melhorar a precisão.
- Confirme a empresa no Maps e obtenha o endereço de email diretamente de uma fonte autorizada. A Places API não devolve emails.
- Introduza a empresa, selecione o idioma e acrescente uma frase específica sobre o negócio, se desejar. Gere a mensagem e reveja o texto, o destinatário e a assinatura.
- Envie individualmente a contactos que autorizaram a comunicação. O Gmail restringe mensagens comerciais não solicitadas. Registe os pedidos de remoção e mantenha o seu registo de autorizações. O painel não lê a caixa de entrada. Consulte as regras aplicáveis a [Portugal](https://diariodarepublica.pt/dr/legislacao-consolidada/lei/2004-106523049) e aos [Estados Unidos](https://www.ftc.gov/business-guidance/resources/can-spam-act-compliance-guide-business).

O servidor atende apenas no endereço local. Os resultados do Maps não são guardados em disco. O painel guarda a sessão de envio em memória. O envio de mensagens é feito pela Gmail API e fica visível na pasta Enviados.

